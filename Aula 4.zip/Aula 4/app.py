from flask import Flask, render_template

app = Flask(__name__)

# Rota para a página inicial (Base Terrestre)
@app.route('/')
def index():
    return render_template('index.html')

# Rota para Marte
@app.route('/marte')
def marte():
    return render_template('marte.html')


if __name__ == '__main__':
    app.run(debug=True)